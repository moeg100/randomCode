CHEMISTRY_TOPICS = [
    {"id": "atomic-structure", "title": "Atomic Structure", "icon": "⚛", "color": "#6c5ce7"},
    {"id": "bonding", "title": "Molecular Structure & Bonding", "icon": "🔗", "color": "#00cec9"},
    {"id": "stoichiometry", "title": "Stoichiometry", "icon": "⚖", "color": "#fdcb6e"},
    {"id": "aqueous", "title": "Aqueous Chemistry", "icon": "💧", "color": "#74b9ff"},
    {"id": "gas-laws", "title": "Gas Laws", "icon": "🎈", "color": "#e17055"},
    {"id": "thermochemistry", "title": "Thermochemistry", "icon": "🔥", "color": "#fd79a8"},
]

FLASHCARDS = {
    "atomic-structure": [
        {"term": "Proton", "definition": "Positively charged subatomic particle (+1) found in the nucleus; determines the element's identity (atomic number)."},
        {"term": "Neutron", "definition": "Neutrally charged subatomic particle found in the nucleus; contributes to atomic mass and isotope identity."},
        {"term": "Electron", "definition": "Negatively charged subatomic particle (−1) that orbits the nucleus; determines chemical bonding and reactions."},
        {"term": "Atomic Number (Z)", "definition": "Number of protons in an atom's nucleus; uniquely identifies an element."},
        {"term": "Mass Number (A)", "definition": "Sum of protons and neutrons in an atom's nucleus."},
        {"term": "Isotope", "definition": "Atoms of the same element with the same number of protons but different numbers of neutrons."},
        {"term": "Aufbau Principle", "definition": "Electrons fill orbitals from lowest energy to highest energy (1s → 2s → 2p → 3s → 3p → 4s → 3d → 4p)."},
        {"term": "Hund's Rule", "definition": "Every orbital in a subshell is singly occupied with one electron before any orbital is doubly occupied, and all electrons in singly occupied orbitals have the same spin."},
        {"term": "Pauli Exclusion Principle", "definition": "No two electrons in an atom can have the same set of four quantum numbers; each orbital can hold at most 2 electrons with opposite spins."},
        {"term": "Electronegativity", "definition": "An atom's ability to attract electrons in a chemical bond; increases across a period, decreases down a group."},
        {"term": "Ionization Energy", "definition": "Energy required to remove one electron from a gaseous atom; increases across a period, decreases down a group."},
        {"term": "Atomic Radius", "definition": "Half the distance between two nuclei of the same element; decreases across a period, increases down a group."},
        {"term": "Orbital", "definition": "A region in space where there is a high probability of finding an electron. Types: s (spherical), p (dumbbell), d (clover), f (complex)."},
        {"term": "Valence Electrons", "definition": "Electrons in the outermost shell (highest n value); responsible for chemical bonding and reactivity."},
        {"term": "Octet Rule", "definition": "Atoms tend to gain, lose, or share electrons to achieve a full set of 8 valence electrons (a noble gas configuration)."},
    ],
    "bonding": [
        {"term": "Ionic Bond", "definition": "Electrostatic attraction between oppositely charged ions formed by complete transfer of electrons (metal + nonmetal)."},
        {"term": "Covalent Bond", "definition": "Sharing of one or more pairs of electrons between two atoms (nonmetal + nonmetal)."},
        {"term": "Polar Covalent Bond", "definition": "Unequal sharing of electrons due to a difference in electronegativity; creates partial charges (δ⁺ and δ⁻)."},
        {"term": "Nonpolar Covalent Bond", "definition": "Equal or nearly equal sharing of electrons; occurs between identical atoms or atoms with similar electronegativity."},
        {"term": "Lewis Structure", "definition": "A diagram showing valence electrons as dots around element symbols; used to visualize bonding and lone pairs."},
        {"term": "VSEPR Theory", "definition": "Valence Shell Electron Pair Repulsion: electron pairs arrange themselves to minimize repulsion, determining molecular shape."},
        {"term": "Tetrahedral Geometry", "definition": "4 electron domains around central atom (e.g., CH₄); bond angles approximately 109.5°."},
        {"term": "Trigonal Planar", "definition": "3 electron domains around central atom (e.g., BF₃); bond angles 120°."},
        {"term": "Linear Geometry", "definition": "2 electron domains around central atom (e.g., CO₂, BeCl₂); bond angle 180°."},
        {"term": "Bent Geometry", "definition": "2 bonding pairs + 1 or 2 lone pairs (e.g., H₂O has bond angle ~104.5°)."},
        {"term": "London Dispersion Forces", "definition": "Weak temporary attractive forces caused by instantaneous dipoles; present in all molecules; increase with molecular size."},
        {"term": "Dipole-Dipole Forces", "definition": "Attraction between the positive end of one polar molecule and the negative end of another."},
        {"term": "Hydrogen Bonding", "definition": "Strong intermolecular force between H bonded to N, O, or F and a lone pair on N, O, or F in another molecule."},
        {"term": "Formal Charge", "definition": "Valence electrons − (nonbonding electrons + ½ bonding electrons); used to determine the best Lewis structure."},
        {"term": "Resonance", "definition": "Delocalization of electrons across multiple bonding positions; the true structure is an average of all resonance forms."},
    ],
    "stoichiometry": [
        {"term": "Mole", "definition": "6.022 × 10²³ particles (Avogadro's number); the SI unit for amount of substance."},
        {"term": "Molar Mass", "definition": "Mass in grams of one mole of a substance; numerically equal to atomic or molecular mass in amu."},
        {"term": "Avogadro's Number", "definition": "6.022 × 10²³; the number of particles (atoms, molecules, formula units) in one mole."},
        {"term": "Empirical Formula", "definition": "Simplest whole-number ratio of atoms in a compound (e.g., CH₂O for glucose)."},
        {"term": "Molecular Formula", "definition": "Exact number of each type of atom in a molecule (e.g., C₆H₁₂O₆ for glucose)."},
        {"term": "Limiting Reactant", "definition": "The reactant that is completely consumed first; determines the maximum amount of product formed."},
        {"term": "Excess Reactant", "definition": "The reactant that is not fully consumed; some remains after the reaction stops."},
        {"term": "Theoretical Yield", "definition": "Maximum amount of product calculated from the limiting reactant using stoichiometry."},
        {"term": "Actual Yield", "definition": "Amount of product actually obtained from a reaction (usually less than theoretical due to losses)."},
        {"term": "Percent Yield", "definition": "(Actual Yield / Theoretical Yield) × 100%; measures reaction efficiency."},
        {"term": "Balanced Equation", "definition": "A chemical equation with equal numbers of each type of atom on both sides; obeys the law of conservation of mass."},
        {"term": "Mole Ratio", "definition": "The stoichiometric ratio between reactants and products from a balanced equation; used to convert between amounts."},
        {"term": "STP (Standard Temperature and Pressure)", "definition": "0°C (273.15 K) and 1 atm; at STP, 1 mole of ideal gas occupies 22.4 L."},
        {"term": "Molarity (M)", "definition": "Moles of solute per liter of solution (mol/L); the most common unit of concentration."},
    ],
    "aqueous": [
        {"term": "Solution", "definition": "A homogeneous mixture of two or more substances; consists of solute (minor component) and solvent (major component)."},
        {"term": "Solute", "definition": "The substance that dissolves in a solvent to form a solution; present in smaller amount."},
        {"term": "Solvent", "definition": "The substance in which a solute dissolves; water is the universal solvent."},
        {"term": "Electrolyte", "definition": "A substance that dissociates into ions in water and conducts electricity (e.g., NaCl, HCl, NaOH)."},
        {"term": "Nonelectrolyte", "definition": "A substance that dissolves but does not produce ions; does not conduct electricity (e.g., sugar, ethanol)."},
        {"term": "Dissociation", "definition": "Separation of an ionic compound into its ions when dissolved in water (e.g., NaCl(s) → Na⁺(aq) + Cl⁻(aq))."},
        {"term": "Precipitation Reaction", "definition": "Reaction where two aqueous solutions form an insoluble solid (precipitate)."},
        {"term": "Solubility Rules", "definition": "Guidelines predicting whether a compound will dissolve in water (e.g., nitrates are always soluble, silver halides are insoluble)."},
        {"term": "Net Ionic Equation", "definition": "Chemical equation showing only the species that actually participate in a reaction; spectator ions are omitted."},
        {"term": "Acid", "definition": "Substance that donates H⁺ ions (protons) in water, according to Arrhenius theory; pH < 7."},
        {"term": "Base", "definition": "Substance that donates OH⁻ ions in water (Arrhenius) or accepts H⁺ ions (Brønsted-Lowry); pH > 7."},
        {"term": "pH", "definition": "−log₁₀[H⁺]; scale from 0 to 14 where 7 is neutral, <7 is acidic, >7 is basic."},
        {"term": "Neutralization", "definition": "Reaction between an acid and a base producing water and a salt: HA + BOH → BA + H₂O."},
        {"term": "Oxidation", "definition": "Loss of electrons by a substance; increase in oxidation state."},
        {"term": "Reduction", "definition": "Gain of electrons by a substance; decrease in oxidation state."},
        {"term": "Oxidation Number", "definition": "A charge assigned to an atom assuming complete electron transfer; used to track redox reactions."},
        {"term": "Spectator Ion", "definition": "An ion that exists in the same form on both sides of a reaction; does not participate chemically."},
    ],
    "gas-laws": [
        {"term": "Boyle's Law", "definition": "P₁V₁ = P₂V₂ at constant T and n; pressure and volume are inversely proportional."},
        {"term": "Charles's Law", "definition": "V₁/T₁ = V₂/T₂ at constant P and n; volume and temperature (in Kelvin) are directly proportional."},
        {"term": "Avogadro's Law", "definition": "V₁/n₁ = V₂/n₂ at constant T and P; volume and number of moles are directly proportional."},
        {"term": "Ideal Gas Law", "definition": "PV = nRT; relates pressure, volume, moles, and temperature of an ideal gas. R = 0.08206 L·atm/mol·K."},
        {"term": "Dalton's Law of Partial Pressures", "definition": "P_total = P₁ + P₂ + P₃ + ...; the total pressure of a gas mixture equals the sum of the partial pressures of each gas."},
        {"term": "Kinetic Molecular Theory", "definition": "Gas particles are in constant random motion, have negligible volume, no intermolecular forces, and undergo elastic collisions."},
        {"term": "Graham's Law of Effusion", "definition": "Rate₁/Rate₂ = √(M₂/M₁); lighter gases effuse faster than heavier gases."},
        {"term": "Ideal Gas", "definition": "Hypothetical gas that perfectly obeys the ideal gas law at all temperatures and pressures; no intermolecular forces."},
        {"term": "Real Gas", "definition": "Actual gas that deviates from ideal behavior at high pressure and low temperature due to intermolecular forces and finite molecular volume."},
        {"term": "Partial Pressure", "definition": "The pressure exerted by a single gas in a mixture of gases; equal to mole fraction × total pressure."},
        {"term": "Mole Fraction", "definition": "Moles of a component divided by total moles in a mixture; used in Dalton's law and concentration calculations."},
        {"term": "Combined Gas Law", "definition": "P₁V₁/T₁ = P₂V₂/T₂; combines Boyle's, Charles's, and Gay-Lussac's laws."},
        {"term": "Standard Molar Volume", "definition": "22.4 L at STP (0°C, 1 atm); the volume occupied by one mole of any ideal gas."},
        {"term": "Vapor Pressure", "definition": "The pressure exerted by a vapor in equilibrium with its liquid phase at a given temperature; increases with temperature."},
    ],
    "thermochemistry": [
        {"term": "Endothermic Process", "definition": "A process that absorbs heat from the surroundings (ΔH > 0); feels cold to the touch."},
        {"term": "Exothermic Process", "definition": "A process that releases heat to the surroundings (ΔH < 0); feels hot to the touch."},
        {"term": "Enthalpy (H)", "definition": "Heat content of a system at constant pressure; H = E + PV."},
        {"term": "Enthalpy Change (ΔH)", "definition": "Heat absorbed or released in a process at constant pressure; ΔH = H_products − H_reactants."},
        {"term": "First Law of Thermodynamics", "definition": "Energy cannot be created or destroyed; it can only be converted from one form to another (ΔU = q + w)."},
        {"term": "Calorimetry", "definition": "Measurement of heat flow in a chemical or physical process using a calorimeter."},
        {"term": "Specific Heat Capacity (c)", "definition": "Amount of heat required to raise 1 gram of a substance by 1°C; q = mcΔT."},
        {"term": "Molar Heat Capacity", "definition": "Amount of heat required to raise the temperature of 1 mole of a substance by 1°C."},
        {"term": "Heat of Fusion (ΔH_fus)", "definition": "Enthalpy change when 1 mole of a solid melts to liquid at its melting point."},
        {"term": "Heat of Vaporization (ΔH_vap)", "definition": "Enthalpy change when 1 mole of a liquid vaporizes to gas at its boiling point."},
        {"term": "Hess's Law", "definition": "The total enthalpy change for a reaction is the sum of the enthalpy changes for each step, regardless of the pathway."},
        {"term": "Standard Enthalpy of Formation (ΔH°_f)", "definition": "Enthalpy change when 1 mole of a compound is formed from its elements in their standard states."},
        {"term": "Bond Energy", "definition": "Energy required to break one mole of a specific bond in the gas phase; bond breaking is endothermic, bond forming is exothermic."},
        {"term": "System vs Surroundings", "definition": "The system is the part of the universe being studied; the surroundings are everything else."},
        {"term": "State Function", "definition": "A property whose value depends only on the current state, not the path taken to reach it (e.g., enthalpy, internal energy, pressure, temperature)."},
    ],
}

QUIZ_QUESTIONS = [
    # --- ATOMIC STRUCTURE ---
    {
        "id": "as-01", "topic": "atomic-structure",
        "variations": [
            "What is the charge of a proton?",
            "A proton carries what type of charge?",
            "Which subatomic particle is positively charged?"
        ],
        "options": [["Positive", "Negative", "Neutral", "Variable"],
                     ["Negative", "Positive", "Neutral", "No charge"],
                     ["Neutron", "Proton", "Electron", "Positron"]],
        "correct": [0, 1, 1],
        "explanation": "Protons have a +1 charge and are located in the nucleus."
    },
    {
        "id": "as-02", "topic": "atomic-structure",
        "variations": [
            "What does the atomic number (Z) represent?",
            "The atomic number of an element is equal to what?",
            "What uniquely identifies a chemical element?"
        ],
        "options": [["Number of protons", "Number of neutrons", "Number of electrons", "Number of protons + neutrons"],
                     ["Number of protons", "Number of neutrons", "Mass of the atom", "Number of valence electrons"],
                     ["Atomic mass", "Number of protons", "Number of neutrons", "Density"]],
        "correct": [0, 0, 1],
        "explanation": "The atomic number (Z) equals the number of protons and uniquely identifies each element."
    },
    {
        "id": "as-03", "topic": "atomic-structure",
        "variations": [
            "What are isotopes?",
            "How do isotopes of the same element differ?",
            "Two atoms of the same element with different masses are called what?"
        ],
        "options": [["Same protons, different neutrons", "Same neutrons, different protons", "Same electrons, different protons", "Different elements"],
                     ["Different number of neutrons", "Different number of protons", "Different number of electrons", "Different chemical properties"],
                     ["Isomers", "Isotopes", "Isotones", "Isobars"]],
        "correct": [0, 0, 1],
        "explanation": "Isotopes have the same number of protons but different numbers of neutrons."
    },
    {
        "id": "as-04", "topic": "atomic-structure",
        "variations": [
            "Which principle states electrons fill lowest energy orbitals first?",
            "Electrons fill orbitals from lowest to highest energy according to what?",
            "What principle determines the order of electron orbital filling?"
        ],
        "options": [["Aufbau principle", "Hund's rule", "Pauli exclusion principle", "Heisenberg uncertainty"],
                     ["Hund's rule", "Pauli exclusion principle", "Aufbau principle", "Bohr model"],
                     ["Octet rule", "Aufbau principle", "Le Chatelier's principle", "Heinsenberg principle"]],
        "correct": [0, 2, 1],
        "explanation": "The Aufbau principle states electrons fill orbitals in order of increasing energy (1s → 2s → 2p → 3s → 3p → ...)."
    },
    {
        "id": "as-05", "topic": "atomic-structure",
        "variations": [
            "How does atomic radius change across a period (left to right)?",
            "Across a period on the periodic table, atomic radius tends to:",
            "Moving left to right on the periodic table, what happens to atomic size?"
        ],
        "options": [["Decreases", "Increases", "Stays the same", "Varies randomly"],
                     ["Increase", "Decrease", "Stay constant", "Double"],
                     ["It increases", "It decreases", "No change", "It depends on the element"]],
        "correct": [0, 1, 1],
        "explanation": "Atomic radius decreases across a period because increasing nuclear charge pulls electrons closer."
    },
    {
        "id": "as-06", "topic": "atomic-structure",
        "variations": [
            "What is electronegativity?",
            "Which best defines electronegativity?",
            "An atom's ability to attract shared electrons is called:"
        ],
        "options": [["Ability to attract electrons in a bond", "Energy to remove an electron", "Size of the atom", "Number of valence electrons"],
                     ["Energy released when an electron is added", "Ability to attract bonding electrons", "Energy to ionize an atom", "Atomic radius"],
                     ["Electronegativity", "Ionization energy", "Electron affinity", "Electropositivity"]],
        "correct": [0, 1, 0],
        "explanation": "Electronegativity is the ability of an atom in a chemical bond to attract shared electrons to itself."
    },

    # --- BONDING ---
    {
        "id": "bd-01", "topic": "bonding",
        "variations": [
            "What type of bond forms between a metal and a nonmetal?",
            "Ionic bonds typically form between:",
            "Complete transfer of electrons results in what type of bond?"
        ],
        "options": [["Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond"],
                     ["Two nonmetals", "A metal and a nonmetal", "Two metals", "A metal and hydrogen"],
                     ["Covalent", "Ionic", "Metallic", "Van der Waals"]],
        "correct": [0, 1, 1],
        "explanation": "Ionic bonds form between a metal (loses electrons) and a nonmetal (gains electrons) through complete electron transfer."
    },
    {
        "id": "bd-02", "topic": "bonding",
        "variations": [
            "What VSEPR geometry has 4 electron domains and bond angles of 109.5°?",
            "A central atom with 4 bonding pairs and no lone pairs has what shape?",
            "What molecular geometry does CH₄ have?"
        ],
        "options": [["Tetrahedral", "Trigonal planar", "Bent", "Linear"],
                     ["Bent", "Linear", "Tetrahedral", "Trigonal pyramidal"],
                     ["Bent", "Linear", "Trigonal planar", "Tetrahedral"]],
        "correct": [0, 2, 3],
        "explanation": "Four electron domains with no lone pairs gives a tetrahedral geometry with 109.5° bond angles (e.g., CH₄, NH₄⁺)."
    },
    {
        "id": "bd-03", "topic": "bonding",
        "variations": [
            "What is the strongest intermolecular force?",
            "Which intermolecular force is the strongest?",
            "Hydrogen bonding occurs between H and which electronegative atoms?"
        ],
        "options": [["Hydrogen bonding", "London dispersion", "Dipole-dipole", "Ionic bonding"],
                     ["London dispersion", "Dipole-dipole", "Hydrogen bonding", "Covalent bonding"],
                     ["C, N, O", "N, O, F", "O, S, Se", "F, Cl, Br"]],
        "correct": [0, 2, 1],
        "explanation": "Hydrogen bonding (between H and N, O, or F) is the strongest intermolecular force, though weaker than ionic or covalent bonds."
    },
    {
        "id": "bd-04", "topic": "bonding",
        "variations": [
            "What shape does water (H₂O) have according to VSEPR?",
            "H₂O has a ________ geometry.",
            "The molecular geometry of water is:"
        ],
        "options": [["Bent", "Linear", "Tetrahedral", "Trigonal planar"],
                     ["linear", "tetrahedral", "bent", "trigonal pyramidal"],
                     ["Linear", "Tetrahedral", "Bent", "Trigonal planar"]],
        "correct": [0, 2, 2],
        "explanation": "H₂O has 2 bonding pairs and 2 lone pairs on oxygen, giving a bent geometry with ~104.5° bond angle."
    },
    {
        "id": "bd-05", "topic": "bonding",
        "variations": [
            "In a polar covalent bond, electrons are:",
            "What characterizes a polar covalent bond?",
            "Unequal sharing of electrons creates what type of bond?"
        ],
        "options": [["Shared unequally", "Transferred completely", "Shared equally", "Not involved"],
                     ["Complete electron transfer", "Equal electron sharing", "Unequal electron sharing", "Free electron movement"],
                     ["Nonpolar covalent", "Polar covalent", "Ionic", "Metallic"]],
        "correct": [0, 2, 1],
        "explanation": "In a polar covalent bond, electrons are shared unequally, creating partial positive (δ⁺) and partial negative (δ⁻) charges."
    },

    # --- STOICHIOMETRY ---
    {
        "id": "st-01", "topic": "stoichiometry",
        "variations": [
            "How many particles are in 1 mole?",
            "Avogadro's number is:",
            "One mole of any substance contains how many entities?"
        ],
        "options": [["6.022 × 10²³", "3.14 × 10²³", "1.00 × 10²⁴", "6.022 × 10²⁴"],
                     ["3.14 × 10²³", "6.022 × 10²³", "1.008 × 10²³", "2.998 × 10²³"],
                     ["6.022 × 10²²", "6.022 × 10²³", "1.000 × 10²⁴", "1.660 × 10²³"]],
        "correct": [0, 1, 1],
        "explanation": "Avogadro's number (6.022 × 10²³) is the number of particles in exactly 1 mole of any substance."
    },
    {
        "id": "st-02", "topic": "stoichiometry",
        "variations": [
            "What is the limiting reactant?",
            "The reactant that limits product formation is called:",
            "Which reactant determines the maximum amount of product formed?"
        ],
        "options": [["The reactant consumed first", "The reactant in excess", "The reactant with the highest mass", "The reactant on the left"],
                     ["Excess reactant", "Limiting reactant", "Catalyst", "Spectator"],
                     ["The one with the smallest coefficient", "The one completely consumed", "The one in excess", "The one with the lowest molar mass"]],
        "correct": [0, 1, 1],
        "explanation": "The limiting reactant is completely consumed first and determines (limits) the amount of product that can form."
    },
    {
        "id": "st-03", "topic": "stoichiometry",
        "variations": [
            "How do you calculate percent yield?",
            "Percent yield equals:",
            "If actual yield is 8g and theoretical is 10g, the percent yield is:"
        ],
        "options": [["(Actual / Theoretical) × 100%", "(Theoretical / Actual) × 100%", "Actual − Theoretical", "Actual + Theoretical"],
                     ["Actual / Theoretical × 100", "Theoretical / Actual × 100", "(Actual − Theoretical) × 100", "Actual × Theoretical"],
                     ["80%", "125%", "20%", "8%"]],
        "correct": [0, 0, 0],
        "explanation": "Percent yield = (Actual yield / Theoretical yield) × 100%. In this case: 8/10 × 100% = 80%."
    },
    {
        "id": "st-04", "topic": "stoichiometry",
        "variations": [
            "What is the difference between empirical and molecular formulas?",
            "An empirical formula shows:",
            "If a compound's molecular formula is C₆H₁₂O₆, its empirical formula is:"
        ],
        "options": [["Empirical = simplest ratio; Molecular = exact count", "Empirical = exact count; Molecular = simplest ratio", "They are the same", "Empirical includes water"],
                     ["The exact number of atoms", "The simplest whole-number ratio of atoms", "The molecular structure", "The three-dimensional shape"],
                     ["CH₂O", "C₆H₁₂O₆", "C₂H₄O₂", "C₁₂H₂₄O₁₂"]],
        "correct": [0, 1, 0],
        "explanation": "Empirical formula is the simplest whole-number ratio (CH₂O for glucose); molecular formula is the actual count (C₆H₁₂O₆)."
    },
    {
        "id": "st-05", "topic": "stoichiometry",
        "variations": [
            "What volume does 1 mole of ideal gas occupy at STP?",
            "At STP, the molar volume of an ideal gas is:",
            "One mole of any ideal gas at 0°C and 1 atm occupies:"
        ],
        "options": [["22.4 L", "24.5 L", "11.2 L", "44.8 L"],
                     ["11.2 L", "22.4 L", "44.8 L", "2.24 L"],
                     ["11.2 L", "22.4 L", "44.8 L", "1.0 L"]],
        "correct": [0, 1, 1],
        "explanation": "At STP (0°C, 1 atm), 1 mole of any ideal gas occupies 22.4 L (standard molar volume)."
    },

    # --- AQUEOUS ---
    {
        "id": "aq-01", "topic": "aqueous",
        "variations": [
            "What is an electrolyte?",
            "A substance that conducts electricity when dissolved in water is a(n):",
            "Which of the following is a strong electrolyte?"
        ],
        "options": [["Substance that dissociates into ions", "Substance that does not dissolve", "Non-reactive substance", "Substance that evaporates easily"],
                     ["Nonelectrolyte", "Electrolyte", "Precipitate", "Solute"],
                     ["Sugar (C₁₂H₂₂O₁₁)", "NaCl", "Ethanol", "Oil"]],
        "correct": [0, 1, 1],
        "explanation": "Electrolytes dissociate into ions in water, allowing electrical conductivity. NaCl is a strong electrolyte."
    },
    {
        "id": "aq-02", "topic": "aqueous",
        "variations": [
            "What is the pH scale range?",
            "A solution with pH < 7 is:",
            "A solution with pH = 7 is:"
        ],
        "options": [["0 to 14", "1 to 10", "−7 to 7", "0 to 7"],
                     ["Basic", "Acidic", "Neutral", "Saline"],
                     ["Acidic", "Basic", "Neutral", "Salt"]],
        "correct": [0, 1, 2],
        "explanation": "pH ranges from 0 to 14. pH < 7 is acidic, pH = 7 is neutral, pH > 7 is basic (alkaline)."
    },
    {
        "id": "aq-03", "topic": "aqueous",
        "variations": [
            "What is the net ionic equation?",
            "Spectator ions in a net ionic equation are:",
            "The net ionic equation shows:"
        ],
        "options": [["Equation with only participating species", "Full balanced equation", "Equation with only products", "Mass-relationship equation"],
                     ["Included", "Omitted", "The only species shown", "Precipitated"],
                     ["All reactants and products", "Only species that undergo a chemical change", "Only gases", "Only the solvent"]],
        "correct": [0, 1, 1],
        "explanation": "Net ionic equations show only species that actually participate in the reaction; spectator ions are omitted."
    },
    {
        "id": "aq-04", "topic": "aqueous",
        "variations": [
            "What is oxidation?",
            "Oxidation involves:",
            "LEO the lion says GER (in redox) means:"
        ],
        "options": [["Loss of electrons", "Gain of electrons", "Gain of protons", "Loss of neutrons"],
                     ["Gain of electrons", "Loss of electrons", "Gain of protons", "Formation of gas"],
                     ["Loss of electrons = oxidation; Gain of electrons = reduction", "Gain = oxidation; Loss = reduction", "Both involve protons", "Neither changes charge"]],
        "correct": [0, 1, 0],
        "explanation": "Oxidation is loss of electrons (LEO); Reduction is gain of electrons (GER)."
    },
    {
        "id": "aq-05", "topic": "aqueous",
        "variations": [
            "What is molarity?",
            "Molarity is defined as:",
            "If you dissolve 1 mol of NaCl in 0.5 L of water, the molarity is:"
        ],
        "options": [["Moles of solute per liter of solution", "Moles of solute per kg of solvent", "Grams of solute per liter", "Volume percent"],
                     ["mol solute / kg solvent", "mol solute / L solution", "g solute / L solution", "L solute / L solution"],
                     ["1 M", "2 M", "0.5 M", "0.25 M"]],
        "correct": [0, 1, 1],
        "explanation": "Molarity = moles of solute / liters of solution. Here, 1 mol / 0.5 L = 2 M."
    },

    # --- GAS LAWS ---
    {
        "id": "gl-01", "topic": "gas-laws",
        "variations": [
            "Boyle's law relates:",
            "According to Boyle's law, if pressure increases, volume:",
            "P₁V₁ = P₂V₂ is the equation for which gas law?"
        ],
        "options": [["Pressure and volume (at constant T)", "Volume and temperature (at constant P)", "Pressure and temperature", "Volume and moles"],
                     ["Increases", "Decreases", "Stays the same", "Triples"],
                     ["Charles's law", "Boyle's law", "Avogadro's law", "Ideal gas law"]],
        "correct": [0, 1, 1],
        "explanation": "Boyle's law (P₁V₁ = P₂V₂) states that pressure and volume are inversely proportional at constant temperature."
    },
    {
        "id": "gl-02", "topic": "gas-laws",
        "variations": [
            "The ideal gas law is:",
            "Which equation represents the ideal gas law?",
            "In PV = nRT, what does R represent?"
        ],
        "options": [["PV = nRT", "P₁V₁ = P₂V₂", "V₁/T₁ = V₂/T₂", "PV = n²RT"],
                     ["P₁V₁ = P₂V₂", "PV = nRT", "PV = nkT", "P = nRT/V"],
                     ["The gas constant", "The ideal pressure", "The universal volume", "The molar ratio"]],
        "correct": [0, 1, 0],
        "explanation": "The ideal gas law is PV = nRT, where R = 0.08206 L·atm/mol·K is the ideal gas constant."
    },
    {
        "id": "gl-03", "topic": "gas-laws",
        "variations": [
            "Dalton's law of partial pressures states:",
            "The total pressure of a gas mixture equals:",
            "If you have 2 atm O₂ and 3 atm N₂, the total pressure is:"
        ],
        "options": [["Total P = sum of partial pressures", "Total P = product of partial pressures", "P₁V₁ = P₂V₂", "Pressure increases with temperature"],
                     ["The largest partial pressure", "The sum of all partial pressures", "The average partial pressure", "The product of all pressures"],
                     ["2 atm", "3 atm", "5 atm", "6 atm"]],
        "correct": [0, 1, 2],
        "explanation": "Dalton's law: P_total = P₁ + P₂ + P₃... So 2 + 3 = 5 atm total."
    },
    {
        "id": "gl-04", "topic": "gas-laws",
        "variations": [
            "Why do real gases deviate from ideal behavior?",
            "Real gases deviate most from ideal behavior at:",
            "Which assumption of kinetic molecular theory fails for real gases?"
        ],
        "options": [["Intermolecular forces and molecular volume", "Gravity and buoyancy", "Temperature fluctuations", "Air resistance"],
                     ["High temperature and low pressure", "Low temperature and high pressure", "Standard conditions", "Only at STP"],
                     ["Particles are in constant motion", "No intermolecular forces", "Elastic collisions", "Random motion"]],
        "correct": [0, 1, 1],
        "explanation": "Real gases deviate at high pressure and low temperature because intermolecular forces and molecular volume become significant."
    },
    {
        "id": "gl-05", "topic": "gas-laws",
        "variations": [
            "Graham's law of effusion compares:",
            "According to Graham's law, a lighter gas effuses:",
            "Rate₁/Rate₂ = √(M₂/M₁) is which gas law?"
        ],
        "options": [["Effusion rates of different gases", "Pressure and volume", "Temperature and volume", "Diffusion in liquids"],
                     ["Slower", "Faster", "At the same rate", "Cannot be determined"],
                     ["Boyle's law", "Charles's law", "Graham's law", "Dalton's law"]],
        "correct": [0, 1, 2],
        "explanation": "Graham's law: lighter gases effuse faster than heavier gases. Rate ∝ 1/√(M)."
    },

    # --- THERMOCHEMISTRY ---
    {
        "id": "th-01", "topic": "thermochemistry",
        "variations": [
            "What is an endothermic process?",
            "An endothermic reaction has what sign for ΔH?",
            "When a process absorbs heat, ΔH is:"
        ],
        "options": [["Absorbs heat (ΔH > 0)", "Releases heat (ΔH < 0)", "No heat change", "Changes phase"],
                     ["ΔH < 0", "ΔH > 0", "ΔH = 0", "ΔH can be anything"],
                     ["Negative (ΔH < 0)", "Positive (ΔH > 0)", "Zero (ΔH = 0)", "Undefined"]],
        "correct": [0, 1, 1],
        "explanation": "Endothermic processes absorb heat from surroundings, so ΔH > 0 (positive)."
    },
    {
        "id": "th-02", "topic": "thermochemistry",
        "variations": [
            "What is the first law of thermodynamics?",
            "The first law of thermodynamics is about:",
            "Energy cannot be created or destroyed — this is the:"
        ],
        "options": [["Energy conservation", "Entropy increase", "Absolute zero", "Heat death"],
                     ["Heat transfer", "Conservation of energy", "Entropy of the universe", "Pressure-volume work"],
                     ["First law of thermodynamics", "Second law of thermodynamics", "Third law of thermodynamics", "Zeroth law"]],
        "correct": [0, 1, 0],
        "explanation": "The first law (ΔU = q + w) states energy is conserved — it can be converted but not created or destroyed."
    },
    {
        "id": "th-03", "topic": "thermochemistry",
        "variations": [
            "Hess's law states that ΔH for a reaction:",
            "According to Hess's law, enthalpy change depends on:",
            "If reaction A → C has ΔH = −100 kJ and A → B has ΔH = −40 kJ, then B → C has ΔH =:"
        ],
        "options": [["Is the sum of ΔH for each step", "Is always negative", "Cannot be calculated", "Depends on temperature"],
                     ["The pathway taken", "Only the initial and final states", "The number of steps", "The catalyst used"],
                     ["−60 kJ", "−140 kJ", "−100 kJ", "+60 kJ"]],
        "correct": [0, 1, 0],
        "explanation": "Hess's law: ΔH is pathway-independent. B → C = (A → C) − (A → B) = −100 − (−40) = −60 kJ."
    },
    {
        "id": "th-04", "topic": "thermochemistry",
        "variations": [
            "What formula relates heat, mass, and temperature change?",
            "The specific heat equation is:",
            "To calculate heat absorbed by a substance, use:"
        ],
        "options": [["q = mcΔT", "q = m/cΔT", "q = mc/ΔT", "q = ΔT/mc"],
                     ["q = mcΔT", "q = mΔT/c", "q = c/mΔT", "q = ΔT/mc"],
                     ["PV = nRT", "q = mcΔT", "ΔH = ΣH_products − ΣH_reactants", "P₁V₁ = P₂V₂"]],
        "correct": [0, 0, 1],
        "explanation": "q = mcΔT, where m is mass, c is specific heat capacity, and ΔT is the temperature change."
    },
    {
        "id": "th-05", "topic": "thermochemistry",
        "variations": [
            "What is standard enthalpy of formation (ΔH°_f)?",
            "The standard enthalpy of formation of an element in its standard state is:",
            "ΔH°_f for any pure element in its standard state is:"
        ],
        "options": [["ΔH to form 1 mole from elements in standard states", "ΔH of combustion", "ΔH of vaporization", "ΔH of fusion"],
                     ["Negative", "Zero", "Positive", "Infinite"],
                     ["Always negative", "Always positive", "Zero", "Depends on the element"]],
        "correct": [0, 1, 2],
        "explanation": "Standard enthalpy of formation (ΔH°_f) is the enthalpy change when 1 mole of a compound forms from its elements. For any element in its standard state, ΔH°_f = 0."
    },
]
