from flask import Flask, jsonify, request, send_from_directory
import random
from content import CHEMISTRY_TOPICS, FLASHCARDS, QUIZ_QUESTIONS

app = Flask(__name__, static_folder='static', static_url_path='/static')

for topic in CHEMISTRY_TOPICS:
    qs = [q for q in QUIZ_QUESTIONS if q['topic'] == topic['id']]
    topic['question_count'] = len(qs)


@app.route('/')
def index():
    return send_from_directory('.', 'index.html')


@app.route('/flashcards')
def flashcards_page():
    return send_from_directory('.', 'flashcards.html')


@app.route('/quiz')
def quiz_page():
    return send_from_directory('.', 'quiz.html')


@app.route('/periodic-table')
def periodic_table():
    return send_from_directory('.', 'periodic-table.html')


@app.route('/molar-mass')
def molar_mass():
    return send_from_directory('.', 'molar-mass.html')


@app.route('/balancing')
def balancing():
    return send_from_directory('.', 'balancing.html')


@app.route('/api/topics')
def api_topics():
    return jsonify(CHEMISTRY_TOPICS)


@app.route('/api/flashcards/<topic_id>')
def api_flashcards(topic_id):
    cards = FLASHCARDS.get(topic_id)
    if cards is None:
        return jsonify({'error': 'Topic not found'}), 404
    topic = next((t for t in CHEMISTRY_TOPICS if t['id'] == topic_id), {})
    return jsonify({
        'topic': topic,
        'cards': cards,
    })


@app.route('/api/quiz/questions', methods=['GET'])
def api_quiz_questions():
    topic = request.args.get('topic', 'all')
    count = request.args.get('count', type=int, default=None)

    if topic == 'all':
        pool = QUIZ_QUESTIONS[:]
    else:
        pool = [q for q in QUIZ_QUESTIONS if q['topic'] == topic]

    if not pool:
        return jsonify({'error': 'No questions found'}), 404

    selected = random.sample(pool, min(count or len(pool), len(pool)))

    questions = []
    for q in selected:
        v_idx = random.randrange(len(q['variations']))
        c_idx = q['correct'][v_idx]
        questions.append({
            'id': q['id'],
            'variation_index': v_idx,
            'question': q['variations'][v_idx],
            'options': q['options'][v_idx],
            'correct': c_idx,
            'explanation': q['explanation'],
        })

    return jsonify(questions)


@app.route('/api/quiz/check', methods=['POST'])
def api_quiz_check():
    data = request.get_json()
    question_id = data.get('id')
    variation_index = data.get('variation_index', 0)
    selected = data.get('selected', -1)

    q = next((x for x in QUIZ_QUESTIONS if x['id'] == question_id), None)
    if q is None:
        return jsonify({'error': 'Question not found'}), 404

    correct_idx = q['correct'][variation_index]
    correct = (selected == correct_idx)

    wrong_variations = []
    if not correct and len(q['variations']) > 1:
        remaining = [i for i in range(len(q['variations'])) if i != variation_index]
        wrong_variations = [{
            'variation_index': i,
            'question': q['variations'][i],
            'options': q['options'][i],
            'correct': q['correct'][i],
        } for i in remaining]

    return jsonify({
        'correct': correct,
        'explanation': q['explanation'],
        'wrong_variations': wrong_variations,
    })


if __name__ == '__main__':
    print('==============================================')
    print('  ChemLearn — Chemistry Study Platform')
    print('==============================================')
    print(f'  {len(CHEMISTRY_TOPICS)} topics, {sum(len(c) for c in FLASHCARDS.values())} flashcards, {len(QUIZ_QUESTIONS)} quiz questions')
    print('  Open: http://localhost:5002')
    print('==============================================')
    app.run(host='127.0.0.1', port=5002, debug=True)
